  EDITPAD CLASSIC README
**************************

Contents
========

  1. What is EditPad Classic?
  2. Do I need to pay for EditPad Classic?
  3. Where can I find the latest information on EditPad Classic?
     How can I contact the author?
  4. How do I install EditPad Classic?
  5. How do I uninstall EditPad Classic?
  6. Some applications still use NotePad instead of EditPad.
     Why? Can I change this?
  7. I sell freeware/shareware CD-ROMs.
     Can I put a copy of EditPad on them?



1. What is EditPad Classic?
===========================

EditPad Classic is a replacement for the standard Windows NotePad.
EditPad Classic requires Windows 95 or later to run. No additional DLLs 
or whatever are required.

Note that EditPad Classic is a finished project.  No enchancements will 
ever be made to it.  Only if any serious bugs would be found, it will 
be updated.
EditPad Classic has been superceded by EditPad Lite and EditPad Pro.  
These versions are the result of redeveloping EditPad from scratch and 
have many interesting new features (certainly EditPad Pro), while still 
remaining as fast and compact as EditPad Classic.
EditPad Lite and EditPad Pro are available at 
http://www.editpadlite.com and http://www.editpadpro.com respectively.

EditPad Classic has some very interesting features:
  * EditPad can open as many files at a time as you want.
  * You change between the open files by clicking on their tabs.
    No hassle with heaps of overlapping windows.
  * If you run EditPad again when there is already an instance running,
    the file(s) you wish to edit will be opened by the existing EditPad
    window.
    This means there will be at most one EditPad window open,
    which will save you from a lot of task switching.
  * If you do need more instances, simply pick View|New editor
    from the menu.
  * If you wish, the EditPad window stays on top of all other windows
  * Block functions:
    Save parts of your text to disk
    Insert a file in the current text
  * Specify many print settings: font, margins, headers/footers, 
    line spacing, etc.
  * Reopen menu that lists the last 16 files opened.
  * Configure the open and save dialog file filters.
  * ANSI <=> OEM (DOS ASCII) conversion.
  * MAPI support.
  * Easy and working installation and uninstallation (see below).
  * It's almost free! (see below)
  * ...



2. Do I need to pay for EditPad Classic?
========================================

EditPad is copyright (C) 1996-2000, by Jan Goyvaerts.

The software (EditPad Classic) is provided "as is". In no event shall 
I, the author, be liable for any consequential, special, incidental or 
indirect damages of any kind arising out of the delivery, performance 
or use of this software. This software has been written with great care 
but I do not warrant that the software is error free.
You may not attempt to reverse compile, modify, translate or 
disassemble the software in whole or in part.

You may freely give copies of EditPad Classic to others, as long as the 
software is unmodified. You may not change a single bit, you may not 
exclude any files or add any to the package and you may not make 
EditPad Classic part of another package.
You may not charge any money for the copying and/or distribution of 
EditPad Classic, also not for EditPad itself.

EditPad Classic is postcardware. You are allowed to install EditPad and 
to try it out for a short while (a week or two), but if you want to 
continue using it you are kindly requested to "pay" by sending the 
author a nice postcard to the address shown below.
A postcard is a piece of thick paper with a pretty picture on one side 
(showing something about where you live, what you do, what you like, 
etc.) and some nice words written by the sender on the other side.
I collect postcards. Only real ones, not the electronic/virtual 
version.
Used phone cards are also welcome, as my sister collects them.

After your postcard has arrived, you are allowed to use EditPad Classic 
for as long and as much as you want, without any other cost. You also 
have the right then to update your copy of EditPad Classicwhen new 
versions come out.
If you mention your email address very clearly on the postcard, I will 
send you a message when I receive your postcard.

Please note that this "payment" is strictly personal. Everyone who uses 
EditPad Classic has to register, even if someone else installed it on 
your computer or if you found it on some CD-ROM you bought. (You paid 
for the CD, not for EditPad Classic.)

Even if EditPad Classic seems to be a simple application, writing it 
was not a very easy task. So if you like it, send me a nice postcard. 
If everyone would say "thank you" when someone else did or said 
something nice, this world would be a much better place.

If you feel that EditPad Classic is definitively worth some money, feel 
free to put your postcard in an envelope and include a few dollars (or 
your local currency). This will surely encourage me to go on with the 
development of new EditPad versions.
You may also consider buying a license to EditPad Pro at 
http://www.editpadpro.com

Send your postcards to this address:

   Jan Goyvaerts
   Lerrekensstraat 5
   2220 Heist-op-den-Berg
      Belgium



3. Where can I find the latest information on EditPad Classic?
   How can I contact the author?
==============================================================

Feel free to visit my web sites at http://www.editpadclassic.com 
and http://www.jgsoft.com to gather the latest news on EditPad.

If you wish to receive an email message when a new version of EditPad 
Classic comes out, feel free to subscribe to my mailing list by filling 
out the form on my web site.

You can contact me (the author) by sending email to 
support@editpadclassic.com

Please note that, even if EditPad Classic is available in many 
languages, I only understand Dutch (Nederlands) and English, so write 
in one of these languages. I can also read German (Deutsch) and French 
(Fran�ais), but the reply will be in English.



4. How do I install EditPad Classic?
====================================

Simply put a copy of EditPad.exe on your hard disk somewhere
(e.g.: c:\Program Files) and run it.

A dialog box displaying the license agreement will pop up. Read the
entire text carefully.
If you agree with it, check the little box below and click on the
button below.
If you do not agree with it, click on the button below to terminate
EditPad.

If you agreed, you will see the EditPad window with an empty text
opened, named "Untitled".
Don't bother about it, just pick Options|Configure from the menu.

A small dialog box will pop up. Check the options you like
and click on OK.

Here's a little more information on the options:
  * Default program for text files:
      Launch EditPad whenever you double-click on a .txt file
      in the Windows Explorer.
    * Use EditPad icon:
        Display EditPad's icon next to .txt files in the Windows
        Explorer.
  * In Send To menu:
      Put a shortcut to EditPad in the Send To menu.
      Then you can right-click on any file in the Explorer and pick
      EditPad from the Send To menu to edit the file with EditPad.
  * Icon on Desktop:
      Put a shortcut to EditPad on your desktop.
  * Icon in Start Menu:
      Put a shortcut to EditPad in the Start Menu
      (menu that appears when you hit the Start button).
  * Icon in Programs menu:
      Put a shortcut to EditPad in the Programs menu of the Start Menu.

That's all there is to it.

If you change your mind later about which options you like, simply
repeat the above procedure.

If you wish to replace the version of EditPad Classic you have 
currently installed with a newer one, simply replace the old 
EditPad.exe on your hard disk with the new one. No other actions are 
necessary.



5. How do I uninstall EditPad Classic?
======================================

There should never be any reason to do so (unless you have upgraded to 
EditPad Pro and don't need Classic any more). If you wish to update 
EditPad Classic to the latest version, simply replace the old 
EditPad.exe on your hard disk with the new one.
However, uninstalling EditPad Classic is an easy thing to do.

Run EditPad Classic and pick Options|Configure from the menu.

Click on the Uninstall button in the dialog box that pops up. This will 
remove all shortcuts that EditPad Classic installed and will also clean 
any information stored in the registry by EditPad Classic.

Close EditPad Classic and delete EditPad.exe from your hard disk.

RIP.



6. Some applications still use NotePad instead of EditPad.
   Why? Can I change this?
==========================================================

These applications execute NotePad directly, instead of running the
program associated to text files.

You can fix this by renaming EditPad.exe to NotePad.exe and putting it
in your Windows directory, overwriting the old NotePad.exe
Then run the new NotePad.exe (EditPad), pick Options|Configure from the
menu and click on OK to update the EditPad links to the new exe.

If you wish to keep a copy of the old NotePad, do NOT rename
NotePad.exe and then copy EditPad.exe to NotePad.exe as Windows
will then update all the links pointing to the renamed NotePad, which
defeats the purpose of overwriting NotePad with EditPad.
Instead, make a copy of NotePad.exe to another folder and then
OVERWRITE NotePad.exe with the renamed EditPad.exe

Note that this trick will not work with Windows 2000 and later, as they 
have a new feature that protects vital system files from being changed 
or deleted.  Notepad.exe is considered a vital system file (go figure).



7. I sell freeware/shareware CD-ROMs.
   Can I put a copy of EditPad Classic on them?
===============================================

If you read this agreement carefully, you know you are not allowed to
charge money for the distribution of EditPad Classic. In other words: 
you can't put it on a CD that must be paid for.

However, if you contact me at editpadclassic@jgsoft.com before putting 
EditPad Classic on a CD I can give you permission to do so. 
This way you can also be sure that you are including the latest version 
of EditPad Classic. You will also have to mention that the people who 
buy the CD, pay for the CD and not for EditPad. If they use it, they 
still have to "pay" by sending me a nice postcard.

Though I will not oblige you to do so, if you put EditPad Classic on a 
CD-ROM, I would really like to receive a free copy of that CD.