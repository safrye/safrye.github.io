EditPad Lite 4.5.4 - 12 February 2003
Copyright (C) 1996-2003 Jan Goyvaerts
http://www.EditPadLite.com
http://www.JustGreatSoftware.com


Welcome to EditPad Lite!

EditPad Lite is designed to be a small but powerful general-purpose text editor.
It is made available free of charge to private persons for purposes that do not generate any income and by registered not-for-profit organizations.

EditPad Pro, which has all the features EditPad Lite has plus a lot more, without becoming bloatware, is available for individual and site licensing for a fee.
EditPad Pro is interesting for those who are not allowed to use the free EditPad Lite (such as commercial and government organizations) and for anybody who needs a really powerful yet easy-to-use text and hexadecimal editor.
You can buy EditPad Pro right now at http://www.editpadpro.com/buynow.html

There is no specific documentation available for EditPad Lite.  However, since all the features EditPad Lite has are also available in EditPad Pro, the help file of EditPad Pro has been included.

For more information on EditPad Lite, please visit its official web site at http://www.EditPadLite.com


Your comments are very welcome at support@editpadlite.com
However, before writing please check http://www.editpadlite.com to see if you have the most recent version.  Writing us about problems with an older version will likely be only a waste of your and our time, which we had rather spent on improving the software.
While your comments are most welcome, note that we cannot provide individual technical support for EditPad Lite.  Free technical support is available for EditPad Pro.

Thank you for using Just Great Software.

Jan Goyvaerts,
founder of JGsoft - Just Great Software