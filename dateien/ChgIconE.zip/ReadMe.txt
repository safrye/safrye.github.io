Change Icon v1.2.1
05/2000

Pierre-Marie DEVIGNE
pmdevigne@nordnet.fr
http://home.nordnet.fr/~pmdevigne/


Install :
=======

Simply copy ChangeIcon.exe wherever you want. For the first ex�cution,
the About box appears, uncheck 'Insert in folders context menu' if you
don't want Change Icon be in this context menu.


Usage :
=======

Change Icon uses a fonction that came with Internet explorer 4 to
allow customize the appearance of folders in the interface.
With Change Icon, it is easy to modify each folder icon individually.
you can also add a tip text that will appear when cursor moves over the
folder.

Launch ChangeIcon.exe directly or select 'Change icon' in a folder
context menu. See the rest by yourself.
I want to tell you though that it supports drag&drop. You can drop a
file containing icons directly over the window. You can also drop a
folder to customize its icon.



Known problems :
================

For some special Windows folders (like Offline Web Pages, History,
etc...), icons names are not shown correctly. However, these folders
cannot be modified by Change Icon.

If you use Microangelo to modify the default folder icon, the original
icon still appears in Change Icon, i must ask to Bill G. why !

The default icon for drives is not correctly managed, it is always the
folder's default icon that appears, but after applied, the correct icon
is showed.

Depends on Windows version, you have to refresh explorer window or
close and reopen it to see the modified icon.

IMPORTANT : under Windows 95 and Windows NT 4, you must have I.E.4 with
shell integration installed (Active Desktop) to see customized icons.
Btw, it is not necessary to use Active Desktop after.


Uninstall Change Icon :
=======================

No automatic uninstall at this time.
Delete the file ChangeIcon.exe manually.
If you want to remove settings, they are saved in the registry here :
HKCU\Software\PMDevigneSoft\ChangeIcon.
Uncheck 'Insert in folders context menu' to remove context menu
(HKCR\Directory\shell\ChangeIcon).


Remarks :
=========

This application is "e-mailware". That is if you like this program or you
want to comment it or to tell me how to enhance it, please send me an
e-mail (see the About dialog box). you can freely copy and distribute
Change Icon if you don't modify it.

This application is provided "AS IS" without warranty of any kind.


Evolutions :
============

v1.2.1 (05/2000)
        Solve a problem with the english version for modifying drives' icons.
v1.2 (04/2000)
        New : drives letters icons are now managed.
        Ini file as been modified for the system consider a modified folder
        as a normal folder (by example, no confirmation is displayed when
        you want to move the folder).
        There was a bug under Windows 2000 when you want to drop a folder
        directly on the Change Icon exe file.
v1.1 (11/1999)
        You can see icons inside a file directly in the browse window.
        It's a cool thing, isn't it ?
        An history for last used file has been added. The lastest file used
        goes in first place.
        A Rebuild button has been created. When icons are mixed up, click
        on it, and all is back to normal.
        Drag & drop has been imroved : you can drop a folder or a file
        anywhere in the window.
        Bugs correction:
        Sometimes, desktop.ini was not deleted when you click OK instead of
        Apply button.
        Some files could hang Change Icon because they contain empty icons
        (shdocvw.dll by example). I had to change the way icons are extracted
        for those files.
        When you used (very) intensively Change Icon without closing its
        window, icons were not still correctly displayed.
        Change Icon understand environment variables.
v1.0 (07/1999)
        - 1st public release
        Allow to modify the appearance of each folder in explorer.
        Drap&drop supported.
        Show a preview of the selected icon in big and small format.
        Tested with I.E.4 et I.E.5, Windows 98 & Windows 2000.
