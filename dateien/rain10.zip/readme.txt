Rain 1.0
By Leading Wintech
------------------

Especially designed for overclockers (or for severe heat conditions),
Rain is the latest CPU cooler from Leading Wintech. What makes
it different from other CPU coolers (such as Waterfall and CPUIdle)
is the fact that it has a different concept: "Extreme Cooling!"

With Rain, you'll get the best cooling under Windows 95/98 nowdays!

Rain was especially designed to give you the biggest temperature 
decrease among all CPU coolers.


Installation
------------

Simply extract the zip file to a temporary directory and run the
install.exe file.

The installation automatically detects and optimizes your CPU.

WARNING: IF YOU RUN THE RAIN.EXE FILE DIRECTLY, RAIN WON'T
DETECT YOUR CPU AND MIGHT NOT WORK AT ALL. PLEASE USE THE SHORTCUTS 
CREATED BY THE INSTALLATION UTILITY IN YOUR START MENU, OR USE THE 
MANUAL OPTIMIZATION.


Manual Optimization
-------------------

If you would like to manually create a shortcut for Rain, 
just add the following switch:

-AMDK5
-AMDK6
-AMDK63D
-IntelPentium
-IntelPentiumMMX
-IntelPentiumPro
-IntelPentiumII
-IntelCeleron
-IntelIMM
-Cyrix5x86
-Cyrix6x86
-Cyrix6x86MX
-IDTC6

For example, if you own a K6, you must type: rain -AMDK6

Frequently Asked Questions
--------------------------

From now on, we will be including a generic Leading Wintech
FAQ file in every release of Rain and Waterfall.

You can find answers to several questions in the FAQ.TXT file.

Technical Support
-----------------

For further information on Rain, as well as the latest news 
and releases, please check out the Leading Wintech websites:

- Official English Website: 
http://cpu.simplenet.com/leading_wintech

- Official Chinese Website:
http://www.geocities.com/SiliconValley/Lab/7403/


Thank you for using Rain!

- Rain programmer: Tim
- Installation programmer: Olivier Gilloire
- Website design and documentation manager: Phil


Copyright (c) 1998, Leading Wintech  