Dup Detector v3.2 (freeware version)
Copyright (C) 2000-2005 Prismatic Software
All Rights Reserved

Duplicate images often find their way into collections, even commercial stock collections. Now you can clean them of duplicates and near duplicates.
Search a folder (including subfolders) for duplicate and near duplicate images. Match all images or restrict match to same size or same aspect ratio.
Dup Detector creates a data file by opening and reading image pixel data for each image in your collection. It then finds duplicates by % match and displays matching pairs from a log file. You may delete a duplicate at any time.
Supports 9 image file formats (jpg,bmp,png,tif,pcx,tga,wmf,emf,psp).
This freeware version requires all images to be in one folder (or subfolders). PhotoBatch version allows use of an image list of folders or files.

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
 SOFTWARE LICENSE
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

This version is free software. It may be freely distributed.

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
 INSTALLATION  Dup Detector freeware version 3.2
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
 SetupDD.exe will install the program Dup Detector.

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
 SYSTEM REQUIREMENTS
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
         
 Windows 95-98 Me 2K NT4 XP.
 486-based PC (Pentium recommended)
 32 MB RAM (recommended)
 VGA monitor with 1000's or millions of color display
 2 MB hard disk space
 Mouse
 MFC42.dll must exist on your system.

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
 UNINSTALLATION
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

 To Uninstall:

 Use the standard uninstall feature "Add/Remove Programs"
 in the Control Panel.

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
 CONTACT
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
 For questions, problems or comments:

 email:
 support@prismaticsoftware.com
 website: http://www.prismaticsoftware.com

 
 

