Context Viewer 1.41 English
Copyright (C) 1999-2000 Schezo.
mailto:schezo@hoehoe.com
http://www.hoehoe.com

Translated by The Serpent Mage


What Is It?

Context Viewer is an explorer extension in the form of a Control Panel applet
that lets you preview image files and text in the right click menu.  It can
also display customized information about images and set hotkeys to enable
or disable the preview along with a few more options.  I personally believe
Context Viewer to be far superior to CyottoMi in many ways, and it could
possibly be an enhanced version of CyottoMi since they are both very similar
in several ways.


What Can It Preview?

Depending if you use plugins or not Context Viewer can pretty much preview any
file you specify, but not every file will necessarily look "nice".  Documents
supported that I know of without any plugins are mainly plaintext files.  Image
preview without any plugins works with bmp, dib, emf, ico, jpg, png, rle, and
wmf files but not with cam, gif, lwf, ldf, mag, pbm, pcx, pgm, ppm, tga, nor tif
files.  There may be more that I have not had the chance to test.


Changes From The Japanese Version

Hopefully everything except the readme file has been translated.  I am not
proficient enough in Japanese nor do I have the patience to translate the
documentation accurately and fully, but the application pretty much explains
itself.  In some cases wording had to be changed in order for text to make
sense in English.  A little bit of the properties dialog was changed for
spacing reasons and aesthetics.


Installation

To install Context viewer just extract ContView.cpl and Setup.exe into the
same directory.  Run Setup.exe and it should tell you that the application
was installed successfully.  The extracted files can now be deleted as they
were copied to the \windows\system directory with Setup.exe renamed to
ContView.exe and ReadMe.txt renamed to ContView.txt if it was also extracted.
Rebooting is not necessary to see the enhancements Context Viewer makes.


How to Use Context Viewer

Just double click on the Context Viewer applet in the Control Panel to
change the settings to what you want.  This is not necessary, but is nice
if you want to change the default hotkeys and information or want to disable
some features.  To see the preview just right click on an image file or
document that is supported.  Clicking on the preview itself or the image
information text will open the default application associated with that
file unless you overrode it in the Context Viewer properties.  There is one
bug with the Document Preview that causes it to not work unless you fix it
by going into the Context Viewer properties under the Documents section and
unchecking then rechecking the Preview Document Text box and hit apply.
This only occurs after the initial installation of Context Viewer and does
not need to be done again.


What Is Susie?

As mentioned in the Plugins section of the properties dialog, you can use
plugins from an application named Susie.  Susie by itself is a Japanese
freeware image editor/viewer.  The interface is easy to understand and the
application alone is pretty simple and unimpressive.  What makes it so
noteworthy and popular is the open plugin api which has led to massive
amounts of plugins created for it.  These plugins add support for not just
more image types but also archives, other file types, and different file
operations besides just viewing.  Its really a nice application to try out
if you also get the official plugins and many of the unofficial plugins
for it.

Official Susie Page
http://www.digitalpad.co.jp/~takechin/

Susie Page with Lots of Plugins
http://www2f.biglobe.ne.jp/~kana/link.html


Uninstallation

To remove Context Viewer just go to Add/Remove Programs in the Control Panel
and remove it from there.  If you want to skip rebooting after the uninstallation
just delete the ContView.exe, ContView.cpl, and ContView.txt files from the
\windows\system directory.  It is not advisable that you do this if you are
upgrading since the upgraded files will be deleted upon rebooting.