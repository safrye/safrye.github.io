Win-Res-Q v1.0
The Lost Window Rescue Tool
(c)1998 HeaT

Check for updates at:

in da HeaT of da Net
http://www.magnetiq.com

Because a major update is on its way... :)
